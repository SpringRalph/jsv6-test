import { create } from "zustand"
import { persist } from "zustand/middleware"
import type { EnvState } from "@/types/env"

interface EnvStore extends EnvState {
  setClientId: (clientId: string) => void
  setSecret: (secret: string) => void
  reset: () => void
}

const initialState: EnvState = {
  clientId: "",
  secret: "",
}

export const useEnvStore = create<EnvStore>()(
  persist(
    (set) => ({
      ...initialState,
      setClientId: (clientId) => set({ clientId }),
      setSecret: (secret) => set({ secret }),
      reset: () => set(initialState),
    }),
    {
      name: "pp-v6-env",
    },
  ),
)
