import type { ReactNode } from "react"

interface CardProps {
  children: ReactNode
  className?: string
}

export function Card({ children, className = "" }: CardProps) {
  return <div className={`bg-card border border-border rounded-lg shadow-sm ${className}`}>{children}</div>
}
