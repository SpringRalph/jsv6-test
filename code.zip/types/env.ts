export interface EnvState {
  clientId: string
  secret: string
}
